- always read README.md before doing anything to familiar with structures.
- avoid manually create migrations, always use cli and auto generate the migrations.
- avoid using useEffect in front projects.
- we have orval in /frontend/packages/api so you can cd to this directory and run pnpm orval to generate react query automatically, the swagger is located in `frontend/packages/api/src/auto-generated/swagger.json`, avoid manually update swagger.json file, instead always copy from specification.json from backend to swagger.json and then call `pnpm orval` to generate or update react queries.
- avoid manually create migration file in backend, instead read root README.md file and see instructions to how to generate new migration.
- always use PaginatedList dto for paginated results in backend.
- in backoffice project every time you had pagination, use `pagination-box.tsx` component.
- i'm using nextjs 16 and tailwind 4. so if you need documentation about these, use context7 mcp.
- Always use context7 when I need code generation, setup or configuration steps, or
  library/API documentation. This means you should automatically use the Context7 MCP
  tools to resolve library id and get library docs without me having to explicitly ask.
- we use shadcn ui, but avoid manually create components, instead use the shadcn npx cli tools.
