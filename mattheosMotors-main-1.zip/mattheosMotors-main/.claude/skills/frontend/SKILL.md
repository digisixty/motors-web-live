---
name: frontend
description: instruction of how we code in frontend project.
---

### Core Services

1. **Web Frontend** (`frontend/apps/web`)

   - Public-facing website
   - Built with Next.js
   - Served on port 3000 (internal)

2. **Backoffice** (`frontend/apps/backoffice`)

   - Admin dashboard
   - Built with Next.js
   - Served on port 3001 (internal)

### Technologies we used

- **Framework**: Next.js 16 with React 19
- **Package Manager**: pnpm with Turborepo for monorepo management
- **Styling**: Tailwind CSS with Radix UI components
- **State Management**: React Query for server state
- **Form Handling**: React Hook Form with Zod validation
- **Icons**: Lucide React
- **Language**: TypeScript

### Local Development

```bash
cd frontend
pnpm install
pnpm dev          # Start all apps in development
pnpm dev:web      # Start only web app
pnpm dev:backoffice # Start only backoffice
```

### Building Docker Images

From the monorepo root:

```bash
cd frontend
docker build -t web-app -f apps/web/Dockerfile .
docker build -t backoffice-app -f apps/backoffice/Dockerfile .
```
