---
name: backend
description: instruction of how we code in backend project.
---

## Backend

### Technologies we used

- **Framework**: .NET 10 with ASP.NET Core
- **Architecture**: Clean Architecture (Domain, Application, Infrastructure layers)
- **Database**: PostgreSQL 15.2
- **ORM**: Entity Framework Core
- **Authentication**: JWT
- **File Storage**: MinIO S3-compatible storage
- **API Documentation**: Swagger/OpenAPI

### Infrastructure & DevOps

- **Containerization**: Docker
- **Orchestration**: Docker Swarm
- **Reverse Proxy**: Nginx
- **CI/CD**: GitHub Actions
- **Database**: PostgreSQL with persistent volumes
- **Object Storage**: MinIO with persistent volumes

### Data Services

5. **PostgreSQL** (`postgres`)

   - Primary database
   - Persistent storage
   - Version 15.2
   - Port 5432 (internal)

6. **MinIO** (`minio`)
   - S3-compatible object storage
   - File uploads, images, documents
   - Persistent storage
   - Console on port 9001 (internal)
   - API on port 9000 (internal)

## 🔧 Development

### Prerequisites

- Docker and Docker Swarm
- pnpm (for frontend development)
- .NET 10 SDK (for backend development)

2. **Backend Development**:

   ```bash
   cd backend
   dotnet restore
   dotnet run        # Run with in-memory database
   ```

### Building Docker Images

From the monorepo root:

```bash
cd ../backend
docker build -t backend-app .
```
