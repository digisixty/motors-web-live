in /frontend project, it is using nextjs 16,
